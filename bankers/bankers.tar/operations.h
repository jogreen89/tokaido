#ifndef OPERATIONS_H
#define OPERATIONS_H

void printOP(void);

void printOP(void) {
    printf("Hello, Operations.\n");
}

#endif
